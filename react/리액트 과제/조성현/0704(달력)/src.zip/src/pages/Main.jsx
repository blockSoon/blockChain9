import {Component} from "react";
import Mycom from "../components/Mycom";

class Main extends Component{
    render(){
        return(
            <>
            7월 달력 <br /><br />
            <Mycom />
            </>
        )
    }
}
export {Main};