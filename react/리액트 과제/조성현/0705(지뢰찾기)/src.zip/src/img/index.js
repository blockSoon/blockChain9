import mine from "./mine.png";

export {mine}