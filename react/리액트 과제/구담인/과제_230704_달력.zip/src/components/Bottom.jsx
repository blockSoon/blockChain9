import React from 'react'
import logo from './logo.png';

const Bottom = () => {
  return (
    <div>
      <img src={logo} alt="" />
      <p>Kyungil Game Academy</p>
    </div>
  )
}

export default Bottom
