import Main from "./Main";
import Win from "./Win";
import Lose from "./Lose";

export {Main, Win, Lose};