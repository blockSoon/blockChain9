import bomb from "./bomb.jpeg";
import flag from "./flag.png";

export {bomb, flag};