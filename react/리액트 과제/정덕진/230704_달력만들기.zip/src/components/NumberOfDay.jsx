
import React from "react";

const NumberOfDay = ({day}) => {
    return (

        <div className="numberOfDay"  >
            {day}
        </div>

    )
}


export default NumberOfDay