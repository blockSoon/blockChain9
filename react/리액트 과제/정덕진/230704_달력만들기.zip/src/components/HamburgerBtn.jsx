

import React from 'react'


const HamburgerBtn = (isClicked) => {
    return (
        <div>
            <button> 📚 </button>
        </div>
    )
}


export default HamburgerBtn







