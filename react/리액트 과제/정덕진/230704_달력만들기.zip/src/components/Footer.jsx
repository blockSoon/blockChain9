

import React from "react";


const Footer = () => {
    return(
        <div className="footer_container" >
            
            <div> DJ </div>
            <div> KGA </div>
            

        </div>
    )
}

export default Footer