


import React from "react";

const RibbonOfDay = () => {
    return(
        <div className="ribbonOfDay">

        </div>
    )
}


export default RibbonOfDay