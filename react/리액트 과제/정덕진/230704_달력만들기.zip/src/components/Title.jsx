

import React from 'react'

const Title = () => {
    return(
        <div> 7월 </div>
    )
}

export default Title

